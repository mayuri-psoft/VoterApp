module.exports = {
  assets: ['./node_modules/react-native-vector-icons/Fonts'],
};
