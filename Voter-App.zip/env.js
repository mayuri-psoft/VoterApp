export default {
    nodeapipath:'http://3.109.134.223:5000/',   
  };
  